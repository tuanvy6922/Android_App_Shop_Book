<?php
include "connect.php";
$search = $_POST['search']; 

$query = "SELECT * FROM sanpham WHERE `tensanpham` LIKE '%".$search."%'";
$data = mysqli_query($conn, $query);
$mangtk = array();
$id=1;
while ($row = mysqli_fetch_assoc($data)) {
    $row['id'] = $id; // Bổ sung khóa "id" với giá trị tăng dần
    $mangtk[] = $row;
    $id++; 
}
if (!empty($mangtk)) {
    $arr = [
        'success' => true, 
        'message' => "thanh cong",
        'result' => $mangtk
    ]; 
}else{
    $arr = [
        'success' => false, 
        'message' => "khong thanh cong",
        'result' => $mangtk
    ]; 
}
echo json_encode($arr);
?>
