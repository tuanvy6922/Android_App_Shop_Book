<?php
    include_once "../config/dbconnect.php";
    
    if(isset($_POST['upload']))
    {
       
        $catname = $_POST['c_name'];
       
         $insert = mysqli_query($conn,"INSERT INTO loaisanpham
         (tenloaisanpham) 
         VALUES ('$catname')");
 
         if(!$insert)
         {
             echo mysqli_error($conn);
             header("Location: ../index.php?loaisanpham=error");
         }
         else
         {
             echo "Records added successfully.";
             header("Location: ../index.php?loaisanpham=success");
         }
     
    }
        
?>