<div id="ordersBtn" >
  <h2>Order Details</h2>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Serial Number</th>
        <th>Customer</th>
        <th>Name Product</th>
        <th>Price Product</th>
        <th>Quantity Product</th>
     </tr>
    </thead>
     <?php
      include_once "../config/dbconnect.php";
      $sql="SELECT madonhang,tenkhachhang,tensanpham,giasanpham,soluongsanpham FROM `chitietdonhang`,`donhang` WHERE chitietdonhang.madonhang=donhang.id";
      $result=$conn-> query($sql);
      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
       <tr>
          <td><?=$row["madonhang"]?></td>
          <td><?=$row["tenkhachhang"]?></td>
          <td><?=$row["tensanpham"]?></td>
          <td><?=$row["giasanpham"]?></td>
          <td><?=$row["soluongsanpham"]?></td>
           
        </tr>
    <?php
            $count=$count+1;
        }
      }
    ?>
     
  </table>
   
</div>
