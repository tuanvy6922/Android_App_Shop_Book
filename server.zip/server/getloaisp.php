<?php
	include "connect.php";
	$query = "SELECT * FROM loaisanpham";
	$data = mysqli_query($conn,$query);
	$mangloaisp = array();
	while ($row = mysqli_fetch_assoc($data)) {
		array_push($mangloaisp,new Loaisp(
			$row['id'],
			$row['tenloaisanpham'],
			$row['hinhminhhoa']));
	}
	echo json_encode($mangloaisp);
	class Loaisp{
		public $id;
		public $tenloaisanpham;
		public $hinhminhhoa;
		public function __construct($id,$tenloaisanpham,$hinhminhhoa){
			$this->id=$id;
			$this->tenloaisanpham=$tenloaisanpham;
			$this->hinhminhhoa=$hinhminhhoa;
		}
	}
?>