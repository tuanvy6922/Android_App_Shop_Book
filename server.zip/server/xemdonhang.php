<?php
include "connect.php";
$mangdonhang = array(); 
$query = "SELECT * FROM chitietdonhang ORDER BY ID DESC ";
$data = mysqli_query($conn, $query);
while ($row = mysqli_fetch_assoc($data)) {
    array_push($mangdonhang, new DonHang(
        $row['id'],
        $row['madonhang'],
        $row['masanpham'],
        $row['tensanpham'],
        $row['giasanpham'],
        $row['soluongsanpham']));
}
echo json_encode($mangdonhang);
class DonHang{
    public $id;
    public $madonhang; // Sử dụng trực tiếp $madonhang
    public $masp;
    public $tensp;
    public $giasp;
    public $slsanpham;
    public function __construct($id,$madh,$masp,$tensp,$giasp,$slsanpham){
        $this->id=$id;
        $this->madonhang=$madh; // Đã sửa từ $madonhang thành $madh
        $this->masp=$masp;
        $this->tensp=$tensp;
        $this->giasp=$giasp;
        $this->slsanpham=$slsanpham;
    }
}
?>
