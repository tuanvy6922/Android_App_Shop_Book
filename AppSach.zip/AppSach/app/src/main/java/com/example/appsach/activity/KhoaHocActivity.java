package com.example.appsach.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.appsach.CheckConnection;
import com.example.appsach.R;
import com.example.appsach.Sanpham;
import com.example.appsach.Server;
import com.example.appsach.adapter.IphoneAdapter;
import com.example.appsach.adapter.KhoahocAdapter;
import com.example.appsach.adapter.VanhoaAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class KhoaHocActivity extends AppCompatActivity {


    Toolbar toolbarkhoahoc;
    ListView lvkhoahoc;
    KhoahocAdapter khoahocAdapter;
    ArrayList<Sanpham> mangkhoahoc;
    int idkhoahoc = 0;
    int page = 1;
    View footerview;
    boolean isLoading = false;
    boolean limitdata = false;
    mHandler mHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_khoa_hoc);

        if (CheckConnection.haveNetworkConnection(getApplicationContext())){
            Anhxa();
            GetIdloaisp();
            ActionToolBar();
            GetData(page);

        }else {
            CheckConnection.ShowToast_Short(getApplicationContext(),"hãy kiểm tra lại internet");
            finish();
        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menugiohang){
            Intent intent = new Intent(getApplicationContext(), com.example.appsach.activity.Giohang.class);
            startActivity(intent);
        }else if (id == R.id.menusearch) {
            Intent searchIntent = new Intent(getApplicationContext(), SearchActivity.class);
            startActivity(searchIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void Anhxa() {
        toolbarkhoahoc = (Toolbar) findViewById(R.id.toolbarkhoahoc);
        lvkhoahoc = (ListView) findViewById(R.id.listviewkhoahoc);
        mangkhoahoc = new ArrayList<>();
        khoahocAdapter = new KhoahocAdapter(getApplicationContext(), mangkhoahoc);
        lvkhoahoc.setAdapter(khoahocAdapter);
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        footerview = inflater.inflate(R.layout.progressbar,null);
        mHandler = new mHandler();

    }
    private void LoadMoreData() {
        lvkhoahoc.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Intent intent = new Intent(getApplicationContext(), ChiTietSanPham.class);
                intent.putExtra("thongtinsanpham", mangkhoahoc.get(i));
                startActivity(intent);
            }
        });
        lvkhoahoc.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {

            }

            @Override
            public void onScroll(AbsListView view, int FirstItem, int VisibleItem, int TotalItem) {
                if(FirstItem + VisibleItem == TotalItem && TotalItem != 0 && isLoading == false && limitdata == false){
                    isLoading = true;
                    ThreadData threadData = new ThreadData();
                    threadData.start();
                }
            }
        });
    }

    private void GetIdloaisp() {
        idkhoahoc = getIntent().getIntExtra("idloaisanpham", -1);
    }
    private void ActionToolBar() {
        setSupportActionBar(toolbarkhoahoc);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarkhoahoc.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void GetData(int Page) {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        String duongdan = Server.Duongdaniphone+String.valueOf(Page);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, duongdan, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                int id = 0;
                String Tenkhoahoc = "";
                int Giakhoahoc = 0;
                String Hinhanhkhoahoc = "";
                String Motakhoahoc = "";
                int Idspkhoahoc = 0;
                if (response!=null && response.length() != 5){
                    lvkhoahoc.removeFooterView(footerview);
                    try {
                        JSONArray jsonArray = new JSONArray(response);
                        for (int i =0;i<jsonArray.length();i++){
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            id = jsonObject.getInt("id");
                            Tenkhoahoc = jsonObject.getString("tensp");
                            Giakhoahoc = jsonObject.getInt("giasp");
                            Hinhanhkhoahoc = jsonObject.getString("hinhanhsp");
                            Motakhoahoc = jsonObject.getString("motasp");
                            Idspkhoahoc = jsonObject.getInt("idsanpham");
                            mangkhoahoc.add(new Sanpham(id,Tenkhoahoc,Giakhoahoc,Hinhanhkhoahoc,Motakhoahoc,Idspkhoahoc));
                            khoahocAdapter.notifyDataSetChanged();
                        }
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                }else {
                    limitdata = true;
                    lvkhoahoc.removeFooterView(footerview);
                    CheckConnection.ShowToast_Short(getApplicationContext(),"Đã hết dữ liệu");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<String,String>();
                param.put("idsanpham",String.valueOf(idkhoahoc));
                return param;
            }
        };
        requestQueue.add(stringRequest);
    }
    public class mHandler extends Handler{
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 0:
                    lvkhoahoc.addFooterView(footerview);
                    break;
                case 1:
                    GetData(++page);
                    isLoading = false;
                    break;
            }
            super.handleMessage(msg);
        }
    }
    public class ThreadData extends Thread{
        @Override
        public void run() {
            mHandler.sendEmptyMessage(0);
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            Message message = mHandler.obtainMessage(1);
            mHandler.sendMessage(message);
            super.run();
        }
    }
}