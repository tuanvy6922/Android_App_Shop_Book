package com.example.appsach;

public class Loaisp {
    public int Id;
    public String Tenloaisanpham;
    public String Hinhminhhoa;

    public Loaisp(int id, String tenloaisanpham, String hinhminhhoa) {
        Id = id;
        Tenloaisanpham = tenloaisanpham;
        Hinhminhhoa = hinhminhhoa;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getTenloaisanpham() {
        return Tenloaisanpham;
    }

    public void setTenloaisanpham(String tenloaisanpham) {
        Tenloaisanpham = tenloaisanpham;
    }

    public String getHinhminhhoa() {
        return Hinhminhhoa;
    }

    public void setHinhminhhoa(String hinhminhhoa) {
        Hinhminhhoa = hinhminhhoa;
    }
}
