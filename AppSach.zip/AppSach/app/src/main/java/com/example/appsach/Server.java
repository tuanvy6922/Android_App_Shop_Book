package com.example.appsach;

public class Server {
    public static String localhost = "192.168.181.190";
    public static String Duongdanloaisp = "http://" + localhost + "/server/getloaisp.php";
    public static String Duongdansanphammoinhat = "http://" + localhost + "/server/getsanphammoinhat.php";
    public static String Duongdaniphone = "http://" + localhost + "/server/getsanpham.php?page=";
    public static String Duongdandonhang = "http://" + localhost + "/server/thongtinkhachhang.php";
    public static String Duongdanchitietdonhang = "http://" + localhost + "/server/chitietdonhang.php";
    public static String Duongdanlaydonhang = "http://" + localhost + "/server/xemdonhang.php";
    public static String Duongdansearch = "http://" + localhost + "/server/timkiem.php";

}
