package com.example.appsach;

public class DonHang {
    public int Madonhang;
    public int Masanpham;
    public String TENsanpham;
    public int GIAsanpham;
    public int SLsanpham;

    public DonHang(int madonhang, int masanpham, String TENsanpham, int GIAsanpham, int SLsanpham) {
        Madonhang = madonhang;
        Masanpham = masanpham;
        this.TENsanpham = TENsanpham;
        this.GIAsanpham = GIAsanpham;
        this.SLsanpham = SLsanpham;
    }

    public int getMadonhang() {
        return Madonhang;
    }

    public void setMadonhang(int madonhang) {
        Madonhang = madonhang;
    }

    public int getMasanpham() {
        return Masanpham;
    }

    public void setMasanpham(int masanpham) {
        Masanpham = masanpham;
    }

    public String getTENsanpham() {
        return TENsanpham;
    }

    public void setTENsanpham(String TENsanpham) {
        this.TENsanpham = TENsanpham;
    }

    public int getGIAsanpham() {
        return GIAsanpham;
    }

    public void setGIAsanpham(int GIAsanpham) {
        this.GIAsanpham = GIAsanpham;
    }

    public int getSLsanpham() {
        return SLsanpham;
    }

    public void setSLsanpham(int SLsanpham) {
        this.SLsanpham = SLsanpham;
    }
}
