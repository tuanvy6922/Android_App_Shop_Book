package com.example.appsach.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.appsach.R;
import com.example.appsach.Sanpham;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.ViewHolder> {
    Context context;
    ArrayList<Sanpham> arraySearch;

    public SearchAdapter(Context context, ArrayList<Sanpham> arraySearch) {
        this.context = context;
        this.arraySearch = arraySearch;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dong_search, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Sanpham sanpham = arraySearch.get(position);
        holder.txttensearch.setText(sanpham.getTensanpham());
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###");
        holder.txtgiasearch.setText("Giá: " + decimalFormat.format(sanpham.getGiasanpham()) + " VNĐ");
        Picasso.with(context).load(sanpham.getHinhanhsanpham())
                .placeholder(R.drawable.noimage)
                .error(R.drawable.error)
                .into(holder.imgsearch);
    }

    @Override
    public int getItemCount() {
        return arraySearch.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView txttensearch, txtgiasearch;
        public ImageView imgsearch;

        public ViewHolder(View itemView) {
            super(itemView);
            txttensearch = itemView.findViewById(R.id.textviewsearch);
            txtgiasearch = itemView.findViewById(R.id.textviewgiasearch);
            imgsearch = itemView.findViewById(R.id.imageviewsearch);
        }
    }
}
