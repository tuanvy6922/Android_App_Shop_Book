package com.example.appsach.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.appsach.R;
import com.example.appsach.Sanpham;
import com.example.appsach.Server;
import com.example.appsach.adapter.IphoneAdapter;
import com.example.appsach.adapter.SanphamAdapter;
import com.example.appsach.adapter.SearchAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SearchActivity extends AppCompatActivity {

    Toolbar toolbarsearch;
    RecyclerView recyclerView;
    EditText edtsearch;
    SearchAdapter searchAdapter;
    SanphamAdapter sanphamAdapter;
    ArrayList<Sanpham> mangtk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Anhxa();
        ActionToolBar();
    }

    private void ActionToolBar() {
        setSupportActionBar(toolbarsearch);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarsearch.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    private void Anhxa() {
        edtsearch = findViewById(R.id.edtSearch);
        toolbarsearch = findViewById(R.id.toolbarSearch);
        recyclerView = findViewById(R.id.recyclerviewSearch);
        mangtk = new ArrayList<>();
        searchAdapter = new SearchAdapter(getApplicationContext(), mangtk);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        edtsearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String keyword = edtsearch.getText().toString().trim();
                // Truyền từ khoá tìm kiếm từ EditText vào phương thức getDataSearch()
                getDataSearch(keyword);
            }
        });
    }

    private void getDataSearch(String keyword) {
        String searchText = edtsearch.getText().toString().trim();
        String url = Server.Duongdansearch;
        // Khởi tạo một RequestQueue bằng Volley
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        // Tạo một StringRequest với method POST
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            if (success) {
                                JSONArray resultArray = jsonResponse.getJSONArray("result");
                                /*List<Sanpham> sanphamList = new ArrayList<>();*/
                                for (int i = 0; i < resultArray.length(); i++) {
                                    JSONObject jsonObject = resultArray.getJSONObject(i);
                                    // Trích xuất thông tin sản phẩm từ jsonObject và thêm vào sanphamList
                                    int ID = jsonObject.getInt("product_id");
                                    String Tensanpham = jsonObject.getString("tensanpham");
                                    int Giasanpham = jsonObject.getInt("giasanpham");
                                    String Hinhanhsanpham = jsonObject.getString("hinhminhhoa");
                                    String Motasanpham = jsonObject.getString("motasanpham");
                                    int IDSanpham = jsonObject.getInt("idsanpham");
                                    mangtk.add(new Sanpham(ID, Tensanpham, Giasanpham, Hinhanhsanpham, Motasanpham, IDSanpham));
                                }
                                // Cập nhật RecyclerView với dữ liệu nhận được từ server
                                searchAdapter = new SearchAdapter(getApplicationContext(), mangtk);
                                recyclerView.setAdapter(searchAdapter);
                                /*recyclerView.setAdapter(searchAdapter);*/
                            } else {
                                // Xử lý trường hợp không có kết quả tìm kiếm
                                Toast.makeText(getApplicationContext(), "Không tìm thấy sản phẩm nào", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "Lỗi xử lý dữ liệu", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Xử lý lỗi ở đây
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            // Gửi các tham số POST nếu cần
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("search", keyword);
                return params;
            }
        };

        // Thêm request vào hàng đợi
        requestQueue.add(stringRequest);
    }

}