package com.example.appsach.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.appsach.CheckConnection;
import com.example.appsach.R;
import com.example.appsach.Sanpham;
import com.example.appsach.Server;
import com.example.appsach.adapter.IphoneAdapter;
import com.example.appsach.adapter.VanhoaAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class VanHoaActivity extends AppCompatActivity {

    Toolbar toolbarvanhoa;
    ListView lvvanhoa;
    VanhoaAdapter vanhoaAdapter;
    ArrayList<Sanpham> mangvanhoa;
    int idvanhoa = 0;
    int page = 1;
    View footerview;
    boolean isLoading = false;
    boolean limitdata = false;
    mHandler mHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_van_hoa);

        if (CheckConnection.haveNetworkConnection(getApplicationContext()))
        {
            Anhxa();
            GetIdloaisp();
            ActionToolBar();
            GetData(page);
            LoadMoreData();

        }else {
            CheckConnection.ShowToast_Short(getApplicationContext(),"Hãy kiểm tra lại internet");
        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menugiohang){
            Intent intent = new Intent(getApplicationContext(), com.example.appsach.activity.Giohang.class);
            startActivity(intent);
        }else if (id == R.id.menusearch) {
            Intent searchIntent = new Intent(getApplicationContext(), SearchActivity.class);
            startActivity(searchIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void Anhxa() {
        toolbarvanhoa = (Toolbar) findViewById(R.id.toolbarvanhoa);
        lvvanhoa = (ListView) findViewById(R.id.listviewvanhoa);
        mangvanhoa = new ArrayList<>();
        vanhoaAdapter = new VanhoaAdapter(getApplicationContext(), mangvanhoa);
        lvvanhoa.setAdapter(vanhoaAdapter);
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        footerview = inflater.inflate(R.layout.progressbar,null);
        mHandler = new mHandler();
    }

    private void LoadMoreData() {
        lvvanhoa.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Intent intent = new Intent(getApplicationContext(), ChiTietSanPham.class);
                intent.putExtra("thongtinsanpham", mangvanhoa.get(i));
                startActivity(intent);
            }
        });
        lvvanhoa.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {

            }

            @Override
            public void onScroll(AbsListView view, int FirstItem, int VisibleItem, int TotalItem) {
                if(FirstItem + VisibleItem == TotalItem && TotalItem != 0 && isLoading == false && limitdata == false){
                    isLoading = true;
                    ThreadData threadData = new ThreadData();
                    threadData.start();
                }
            }
        });
    }
    private void GetIdloaisp() {
        idvanhoa = getIntent().getIntExtra("idloaisanpham", -1);
    }
    private void ActionToolBar() {
        setSupportActionBar(toolbarvanhoa);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarvanhoa.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }



    private void GetData(int Page) {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        String duongdan = Server.Duongdaniphone+String.valueOf(Page);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, duongdan, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                int id = 0;
                String Tenvanhoa = "";
                int Giavanhoa = 0;
                String Hinhanhvanhoa = "";
                String Motavanhoa = "";
                int Idspvanhoa = 0;
                if (response!=null && response.length() != 2){
                    lvvanhoa.removeFooterView(footerview);
                    try {
                        JSONArray jsonArray = new JSONArray(response);
                        for (int i =0;i<jsonArray.length();i++){
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            id = jsonObject.getInt("id");
                            Tenvanhoa = jsonObject.getString("tensp");
                            Giavanhoa = jsonObject.getInt("giasp");
                            Hinhanhvanhoa = jsonObject.getString("hinhanhsp");
                            Motavanhoa = jsonObject.getString("motasp");
                            Idspvanhoa = jsonObject.getInt("idsanpham");
                            mangvanhoa.add(new Sanpham(id,Tenvanhoa,Giavanhoa,Hinhanhvanhoa,Motavanhoa,Idspvanhoa));
                            vanhoaAdapter.notifyDataSetChanged();
                        }
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                }else {
                    limitdata = true;
                    lvvanhoa.removeFooterView(footerview);
                    CheckConnection.ShowToast_Short(getApplicationContext(),"Đã hết dữ liệu");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<String,String>();
                param.put("idsanpham",String.valueOf(idvanhoa));
                return param;
            }
        };
        requestQueue.add(stringRequest);
    }

    public class mHandler extends Handler{
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 0:
                    lvvanhoa.addFooterView(footerview);
                    break;
                case 1:
                    GetData(++page);
                    isLoading = false;
                    break;
            }
            super.handleMessage(msg);
        }
    }
    public class ThreadData extends Thread{
        @Override
        public void run() {
            mHandler.sendEmptyMessage(0);
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            Message message = mHandler.obtainMessage(1);
            mHandler.sendMessage(message);
            super.run();
        }
    }
}