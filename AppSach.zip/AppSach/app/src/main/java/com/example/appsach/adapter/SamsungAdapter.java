package com.example.appsach.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.appsach.R;
import com.example.appsach.Sanpham;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class SamsungAdapter extends BaseAdapter {
    Context context;
    ArrayList<Sanpham> arraySamsung;

    public SamsungAdapter(Context context, ArrayList<Sanpham> arraySamsung) {
        this.context = context;
        this.arraySamsung = arraySamsung;
    }

    @Override
    public int getCount() {
        return arraySamsung.size();
    }

    @Override
    public Object getItem(int i) {
        return arraySamsung.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }
    public class ViewHolder{
        public TextView txttensamsung, txtgiaisamsung, txtmotasamsung;
        public ImageView imgsamsung;
    }
    @Override
    public View getView(int i, View view, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (view == null){
            viewHolder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.dong_samsung, null);
            viewHolder.txttensamsung = (TextView) view.findViewById(R.id.textviewsamsung);
            viewHolder.txtgiaisamsung = (TextView) view.findViewById(R.id.textviewgiasamsung);
            viewHolder.txtmotasamsung = (TextView) view.findViewById(R.id.textviewmotasamsung);
            viewHolder.imgsamsung = (ImageView) view.findViewById(R.id.imageviewsamsung);
            view.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) view.getTag();
        }
        Sanpham sanpham = (Sanpham) getItem(i);
        viewHolder.txttensamsung.setText(sanpham.getTensanpham());
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###");
        viewHolder.txtgiaisamsung.setText("Giá : " + decimalFormat.format(sanpham.getGiasanpham())+" VNĐ");
        viewHolder.txtmotasamsung.setMaxLines(2);
        viewHolder.txtmotasamsung.setEllipsize(TextUtils.TruncateAt.END);
        viewHolder.txtmotasamsung.setText(sanpham.getMotasanpham());
        Picasso.with(context).load(sanpham.getHinhanhsanpham())
                .placeholder(R.drawable.noimage)
                .error(R.drawable.error)
                .into(viewHolder.imgsamsung);
        return view;
    }
}
