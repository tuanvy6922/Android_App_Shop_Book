package com.example.appsach.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.appsach.DonHang;
import com.example.appsach.R;
import com.example.appsach.Sanpham;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class XemDonHangAdapter extends BaseAdapter {

    Context context;
    ArrayList<DonHang> arrayxemdh;

    public XemDonHangAdapter(Context context, ArrayList<DonHang> arrayxemdh) {
        this.context = context;
        this.arrayxemdh = arrayxemdh;
    }

    @Override
    public int getCount() {
        return arrayxemdh.size();
    }

    @Override
    public Object getItem(int position) {
        return arrayxemdh.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    public class ViewHolder{
        public TextView txtmadonhang,txttendonhang,txtsldonhang,txttongtiendh;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (view ==null){
            viewHolder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.dong_donhang, null);
            viewHolder.txtmadonhang = (TextView) view.findViewById(R.id.textviewMADH);
            viewHolder.txttendonhang = (TextView) view.findViewById(R.id.textviewTENDH);
            viewHolder.txtsldonhang = (TextView) view.findViewById(R.id.textviewmotaSLDH);
            viewHolder.txttongtiendh = (TextView) view.findViewById(R.id.textviewTienDH);
            view.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) view.getTag();
        }
        DonHang donhang = (DonHang) getItem(position);
        viewHolder.txtmadonhang.setText(String.valueOf(donhang.getMadonhang()));
        viewHolder.txttendonhang.setText(String.valueOf(donhang.getTENsanpham()));
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###");
        viewHolder.txttongtiendh.setText(decimalFormat.format(donhang.getGIAsanpham())+" VNĐ");
        viewHolder.txtsldonhang.setText(String.valueOf(donhang.getSLsanpham()));
        return view;
    }
}
