package com.example.appsach.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.appsach.CheckConnection;
import com.example.appsach.DonHang;
import com.example.appsach.Loaisp;
import com.example.appsach.R;
import com.example.appsach.Sanpham;
import com.example.appsach.Server;
import com.example.appsach.adapter.XemDonHangAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class XemDonHangActivity extends AppCompatActivity {

    Toolbar toolbarxemdonhang;
    ListView lvdonhang;
    XemDonHangAdapter xemDonHangAdapter;
    ArrayList<DonHang> mangdh;
    int idDH = 0;
    int page = 1;
    View footerview;
    boolean isLoading = false;
    boolean limitdata = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xem_don_hang);
        Anhxa();
        if (CheckConnection.haveNetworkConnection(getApplicationContext())){
            ActionToolBar();
            GetXemDonHang();
        }else{
            CheckConnection.ShowToast_Short(getApplicationContext(),"Bạn hãy kiểm tra lại kết nối");
            finish();
        }


    }
    private void GetXemDonHang() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Server.Duongdanlaydonhang, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                if (response != null){
                    for (int i = 0; i<response.length();i++){
                        try {
                            JSONObject jsonObject = response.getJSONObject(i);
                            int maDH = jsonObject.getInt("madonhang");
                            int masanpham = jsonObject.getInt("masp");
                            String tensanpham = jsonObject.getString("tensp");
                            int giasanpham = jsonObject.getInt("giasp");
                            int soluongsanpham = jsonObject.getInt("slsanpham");
                            mangdh.add(new DonHang(maDH,masanpham,tensanpham,giasanpham,soluongsanpham));
                            xemDonHangAdapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        requestQueue.add(jsonArrayRequest);
    }

    /*private void GetData() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        String duongdan = Server.Duongdanlaydonhang+String.valueOf(Page);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, duongdan, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                int id = 0;
                int madonhang = 0;
                int masanpham = 0;
                String tensanpham = "";
                String giasanpham = "";
                int soluongsanpham = 0;
                if (response != null && response.length() != 2) {
                    try {
                        // Phân tích phản hồi JSON để lấy các thông tin của đơn hàng
                        JSONArray jsonArray = new JSONArray(response);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);

                            // Trích xuất dữ liệu từ các biến đã được thêm vào trước đó
                            int id = jsonObject.getInt("id");
                            int madonhang = jsonObject.getInt("madonhang");
                            int masanpham = jsonObject.getInt("masanpham");
                            String tensanpham = jsonObject.getString("tensanpham");
                            String giasanpham = jsonObject.getString("giasanpham");
                            int soluongsanpham = jsonObject.getInt("soluongsanpham");

                            // Thêm dữ liệu vào danh sách đơn hàng (mangdh)
                            mangdh.add(new DonHang(id, madonhang, masanpham, tensanpham, giasanpham, soluongsanpham));

                            // Cập nhật adapter để hiển thị dữ liệu mới
                            xemDonHangAdapter.notifyDataSetChanged();
                        }
                    } catch (JSONException e) {
                        // Xử lý ngoại lệ nếu có lỗi khi phân tích JSON
                        throw new RuntimeException(e);
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<String,String>();
                param.put("madh",String.valueOf(idDH=0));
                return param;
            }
        };
        requestQueue.add(stringRequest);
    }*/


    private void ActionToolBar() {
        setSupportActionBar(toolbarxemdonhang);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarxemdonhang.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


    private void Anhxa() {
        toolbarxemdonhang = (Toolbar) findViewById(R.id.toolbarxemdonhang);
        lvdonhang = (ListView) findViewById(R.id.listviewxemdonhang);
        mangdh = new ArrayList<>();
        xemDonHangAdapter = new XemDonHangAdapter(getApplicationContext(),mangdh);
        lvdonhang.setAdapter(xemDonHangAdapter);
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
    }
}