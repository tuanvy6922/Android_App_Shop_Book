package com.example.appsach.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.appsach.R;
import com.example.appsach.Sanpham;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class KhoahocAdapter extends BaseAdapter {

    Context context;
    ArrayList<Sanpham> arraykhoahoc;

    public KhoahocAdapter(Context context, ArrayList<Sanpham> arraykhoahoc) {
        this.context = context;
        this.arraykhoahoc = arraykhoahoc;
    }

    @Override
    public int getCount() {
        return arraykhoahoc.size();
    }

    @Override
    public Object getItem(int i) {
        return arraykhoahoc.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }
    public class ViewHolder{
        public TextView txttenkhoahoc, txtgiakhoahoc, txtmotakhoahoc;
        public ImageView imgkhoahoc;
    }
    @Override
    public View getView(int i, View view, ViewGroup parent) {
        KhoahocAdapter.ViewHolder viewHolder = null;
        if (view == null){
            viewHolder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.dong_khoahoc, null);
            viewHolder.txttenkhoahoc = (TextView) view.findViewById(R.id.textviewkhoahoc);
            viewHolder.txtgiakhoahoc = (TextView) view.findViewById(R.id.textviewgiakhoahoc);
            viewHolder.txtmotakhoahoc = (TextView) view.findViewById(R.id.textviewmotakhoahoc);
            viewHolder.imgkhoahoc = (ImageView) view.findViewById(R.id.imageviewkhoahoc);
            view.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) view.getTag();
        }
        Sanpham sanpham = (Sanpham) getItem(i);
        viewHolder.txttenkhoahoc.setText(sanpham.getTensanpham());
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###");
        viewHolder.txtgiakhoahoc.setText("Giá: " + decimalFormat.format(sanpham.getGiasanpham())+" VNĐ");
        viewHolder.txtmotakhoahoc.setMaxLines(2);
        viewHolder.txtmotakhoahoc.setEllipsize(TextUtils.TruncateAt.END);
        viewHolder.txtmotakhoahoc.setText(sanpham.getMotasanpham());
        Picasso.with(context).load(sanpham.getHinhanhsanpham())
                .placeholder(R.drawable.noimage)
                .error(R.drawable.error)
                .into(viewHolder.imgkhoahoc);
        return view;
    }
}
